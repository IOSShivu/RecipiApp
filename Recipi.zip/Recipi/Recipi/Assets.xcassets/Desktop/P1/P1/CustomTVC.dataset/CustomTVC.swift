//
//  CustomTVC.swift
//  P1
//
//  Created by DCS on 26/11/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class CustomTVC: UIViewController {

    private let mytbv = UITableView();
    private var cityarray=["Berlin","Rio","Moscow","Tokyo"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title="Custom Table View"
        view.addSubview(mytbv)
        setupTableView()
        
        // Do any additional setup after loading the view.
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        mytbv.frame=CGRect(x: 0, y: view.safeAreaInsets.top, width:view.width, height: view.height-view.safeAreaInsets.top-view.safeAreaInsets.bottom)
    }
}
extension CustomTVC:UITableViewDelegate,UITableViewDataSource
{  private func setupTableView()
    {
        mytbv.dataSource=self
        mytbv.delegate=self
        mytbv.register(CityCell.self, forCellReuseIdentifier: "CityCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "CityCell",for:indexPath) as! CityCell
       // cell.textLabel?.text=cityarray[indexPath.row]
        cell.setupCityCellWith(title: cityarray[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
