//
//  CityCell.swift
//  P1
//
//  Created by DCS on 26/11/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class CityCell: UITableViewCell {

    private let myImageView:UIImageView =
    {
        let imgview=UIImageView()
        imgview.contentMode = .scaleAspectFill
        imgview.layer.cornerRadius=40
        imgview.clipsToBounds = true
        return imgview
        
    }()
    
    private let myLabel:UILabel = {
        let lbl = UILabel()
        lbl.font = .boldSystemFont(ofSize:28)
        return lbl
    }()
    
    func setupCityCellWith(title name:String)
    {
        contentView.addSubview(myImageView)
        contentView.addSubview(myLabel)
        myImageView.frame = CGRect(x: 20, y: 20, width: 80, height: 80)
        myLabel.frame = CGRect(x: myImageView.right + 20, y: 20, width: 200, height: 80)
        myImageView.image = UIImage(named: name)
        myLabel.text = name
    }
}

