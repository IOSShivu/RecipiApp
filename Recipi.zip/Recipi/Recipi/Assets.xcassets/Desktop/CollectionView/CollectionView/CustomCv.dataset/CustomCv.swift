//
//  CustomCv.swift
//  CollectionView
//
//  Created by DCS on 26/11/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class CustomCv: UIViewController {
    private let mycv = UICollectionView();
    private var cityarray=["Berlin","Rio","Moscow","Tokyo"]
    override func viewDidLoad() {
        super.viewDidLoad()
        title="Custom Collection View"
        view.addSubview(mycv)
        
        
        // Do any additional setup after loading the view.
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        mycv.frame=CGRect(x: 0, y: view.safeAreaInsets.top, width:view.width, height: view.height-view.safeAreaInsets.top-view.safeAreaInsets.bottom)
    }
}
extension CustomCv:UICollectionViewDataSource,UICollectionViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cityarray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "CityCell", for: indexPath)
        cell
        return cell
        
    }
    private func setupTableView()
{
    mycv.dataSource=self
    mycv.delegate=self
    mycv.register(UIViewController.self, forCellWithReuseIdentifier: "CityCell")
    }
    
    
}
