//
//  AddNoteVC.swift
//  M209228
//
//  Created by DCS on 08/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class AddNoteVC: UIViewController {
    private var note:UITextView{
        let nm=UITextView()
        nm.text="Enter Note:"
        nm.autocapitalizationType = .none
        nm.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return nm
    }
    private var category:UITextField{
        let pwd=UITextField()
        pwd.placeholder="Enter Category:"
        pwd.autocapitalizationType = .none
        pwd.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return pwd
    }
    private var save:UIButton{
        let btn=UIButton()
        btn.setTitle("Save", for: .normal)
        btn.addTarget(self, action:#selector(saveNote), for: .touchUpInside)
        btn.backgroundColor=#colorLiteral(red: 0.06274510175, green: 0, blue: 0.1921568662, alpha: 1)
        btn.setTitleColor(.white, for: .normal)
        return btn
    }
    @objc func saveNote(){
        print("save")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(note)
        view.addSubview(category)
        view.addSubview(save)
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        note.frame=CGRect(x: 20, y: 80, width: view.width - 40, height: 80)
        category.frame=CGRect(x: 20, y: note.height + 10, width: view.width - 40, height: 40)
        save.frame=CGRect(x: 20, y: category.height + 20, width: view.width - 40, height: 40)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
