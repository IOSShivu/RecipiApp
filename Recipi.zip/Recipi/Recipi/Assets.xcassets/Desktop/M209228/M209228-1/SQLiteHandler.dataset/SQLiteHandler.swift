//
//  SQLiteHandler.swift
//  M209228
//
//  Created by DCS on 08/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import Foundation
import SQLite3

class SQLiteHandler{
    
    static public var shared = SQLiteHandler()
    
    let dbpath="NoteDB.SQLite"
    var db:OpaquePointer?
    
    public init()
    {
        db=openDatabase()
        createTable()
    }
    //let database:OpaquePointer?nil
    func openDatabase() -> OpaquePointer {
       var database:OpaquePointer!=nil
    return database
    }
    func createTable() -> OpaquePointer {
        let createString="""
 CREATE TABLE IF NOT EXIST Note (
 id INTEGER PRIMARY KEY AUTO INCREMENT,
 note Text ,
 category Text);
 """
        var createStatement:OpaquePointer!=nil
        if sqlite3_prepare_v3(db, createString, -1,1, &createStatement,nil) == SQLITE_OK{
            if sqlite3_step(createStatement) == SQLITE_DONE{
                print("Database Created Successfully")
            }
            else{
                print("Database not created")
            }
        }
        else{
            print("cant create datbase")
        }
        sqlite3_finalize(createStatement)
        return createStatement
    }
}
