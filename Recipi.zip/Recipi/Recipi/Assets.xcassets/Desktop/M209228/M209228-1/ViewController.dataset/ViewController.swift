//
//  ViewController.swift
//  M209228
//
//  Created by DCS on 08/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private var username:UITextField{
       let nm=UITextField()
        nm.placeholder="Enter UserName:"
        nm.autocapitalizationType = .none
        nm.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return nm
    }
    private var password:UITextField{
        let pwd=UITextField()
        pwd.placeholder="Enter Password:"
        pwd.autocapitalizationType = .none
        pwd.isSecureTextEntry = true
        pwd.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return pwd
    }
    private var register:UIButton{
        let btn=UIButton()
        btn.setTitle("RegisterNow", for: .normal)
        btn.addTarget(self, action:#selector(registertapped), for: .touchUpInside)
        btn.backgroundColor=#colorLiteral(red: 0.06274510175, green: 0, blue: 0.1921568662, alpha: 1)
        btn.setTitleColor(.white, for: .normal)
        return btn
    }
    @objc func registertapped(){
        print("Inside Register")
        if username.text==""
        {
            let alert=UIAlertController(title: "UserNameBlank", message: "Please enter username .user name cannnot be blank.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else if password.text==""
        {
            let alert=UIAlertController(title: "PasswordBlank", message: "Please enter Password .Password cannnot be blank.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else
        {
            UserDefaults.standard.set(username.text, forKey: "username")
            UserDefaults.standard.set(password.text, forKey: "password")
            let vc = loginVC()
            navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(username)
        view.addSubview(password)
        view.addSubview(register)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        username.frame=CGRect(x: 20, y: 80, width: view.width - 40, height: 40)
        password.frame=CGRect(x: 20, y: username.height + 10, width: view.width - 40, height: 40)
        register.frame=CGRect(x: 20, y: password.height + 20, width: view.width - 40, height: 40)
    }

}

