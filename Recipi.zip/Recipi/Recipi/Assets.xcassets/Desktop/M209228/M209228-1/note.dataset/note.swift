//
//  note.swift
//  M209228
//
//  Created by DCS on 08/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import Foundation
class note {
    var id:Int = 0
    var note:String = ""
    var category:String = ""
    
    
    init(id:Int,note:String,category:String){
        self.id=id
        self.note=note
        self.category=category
    }
}
