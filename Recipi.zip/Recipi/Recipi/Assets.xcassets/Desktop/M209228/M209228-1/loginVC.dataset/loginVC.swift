//
//  loginVC.swift
//  M209228
//
//  Created by DCS on 08/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class loginVC: UIViewController {
    private var username:UITextField{
        let nm=UITextField()
        nm.placeholder="Enter UserName:"
        nm.autocapitalizationType = .none
        nm.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return nm
    }
    private var password:UITextField{
        let pwd=UITextField()
        pwd.placeholder="Enter Password:"
        pwd.autocapitalizationType = .none
        pwd.isSecureTextEntry = true
        pwd.backgroundColor=#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        return pwd
    }
    private var login:UIButton{
        let btn=UIButton()
        btn.setTitle("LoginNow", for: .normal)
        btn.addTarget(self, action:#selector(logintapped), for: .touchUpInside)
        btn.backgroundColor=#colorLiteral(red: 0.06274510175, green: 0, blue: 0.1921568662, alpha: 1)
        btn.setTitleColor(.white, for: .normal)
        return btn
    }
    @objc func logintapped(){
        print("Inside login")
        let uname = UserDefaults.standard.string(forKey: "username")
        let pwd = UserDefaults.standard.string(forKey: "password")
        if username.text==""
        {
            let alert=UIAlertController(title: "UserNameBlank", message: "Please enter username .user name cannnot be blank.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else if password.text==""
        {
            let alert=UIAlertController(title: "PasswordBlank", message: "Please enter Password .Password cannnot be blank.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else if username.text != uname{
            let alert=UIAlertController(title: "IncorrectUsername", message: "Please enter valid user name .You enter wrong username.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else if password.text != pwd{
            let alert=UIAlertController(title: "IncorrectPassword", message: "Please enter valid password .You enter wrong password.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
        else
        {
            
            let vc = homeVC()
            navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(username)
        view.addSubview(password)
        view.addSubview(login)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        username.frame=CGRect(x: 20, y: 80, width: view.width - 40, height: 40)
        password.frame=CGRect(x: 20, y: username.height + 10, width: view.width - 40, height: 40)
        login.frame=CGRect(x: 20, y: password.height + 20, width: view.width - 40, height: 40)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
