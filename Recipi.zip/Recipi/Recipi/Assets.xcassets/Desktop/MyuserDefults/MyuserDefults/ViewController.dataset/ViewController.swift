//
//  ViewController.swift
//  MyuserDefults
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private let usernamelbl: UILabel = {
    let lbl = UILabel()
    lbl.text = ""
    lbl.textAlignment = .center
    lbl.backgroundColor = .red
    return lbl
    }()
    
    private let logoutbtn: UIButton = {
    let btn = UIButton()
    btn.setTitle("", for: .normal)
        btn.addTarget(self, action: #selector(logouttrapped), for: .touchUpInside)
        btn.backgroundColor = .green
        btn.layer.cornerRadius = 6
    return btn
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(usernamelbl)
        view.addSubview(logoutbtn)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        checkAuth()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        usernamelbl.frame = CGRect(x: 40, y: 200, width: view.width - 80, height: 40)
        logoutbtn.frame = CGRect(x: 40, y: usernamelbl.bottom + 20, width: view.width - 80, height: 40)
        
}
private func checkAuth()
{
    if let uname = UserDefaults.standard.string(forKey: "username")
    {
    usernamelbl.text = "Welcome \(uname)"
    }
    else
    {
        let vc = LoginVc()
        let nav = UINavigationController(rootViewController: vc)
        nav.modalPresentationStyle = .fullScreen
        nav.setToolbarHidden(true, animated: false)
        present(nav,animated:false)
        
    }
}
@objc private func logouttrapped()
{
    UserDefaults.standard.set(nil, forKey: "uname")
}
}
