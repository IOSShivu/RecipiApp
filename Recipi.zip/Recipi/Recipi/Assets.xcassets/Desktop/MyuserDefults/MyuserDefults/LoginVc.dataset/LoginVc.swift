//
//  LoginVc.swift
//  MyuserDefults
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class LoginVc: UIViewController {
    private let loginbtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("", for: .normal)
        btn.addTarget(self, action: #selector(logintrapped), for: .touchUpInside)
        btn.backgroundColor = .green
        btn.layer.cornerRadius = 6
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(loginbtn)
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
         loginbtn.frame = CGRect(x: 40, y: 200, width: view.width - 80, height: 40)    }
    
    @objc private func logintrapped()
    {
        UserDefaults.standard.set("shivani", forKey: "username")
        self.dismiss(animated: true)
    }
}

