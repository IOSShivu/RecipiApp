//
//  newNote.swift
//  myFileManager
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class newNote: UIViewController {

    private let nameTxtField : UITextField = {
        let txtfield = UITextField()
        txtfield.placeholder = ""
        txtfield.textAlignment = .center
        txtfield.borderStyle = .roundedRect
        txtfield.backgroundColor = .lightGray
        return txtfield
    }()
    
    private let contantTxtView : UITextField = {
        let txtview = UITextField()
        txtview.placeholder = ""
        txtview.textAlignment = .center
        txtview.borderStyle = .roundedRect
        txtview.backgroundColor = .lightGray
        return txtview
    }()
    
    private let saveBtn : UIButton = {
        let btn = UIButton()
       btn.setTitle("", for: .normal)
        btn.addTarget(self, action: #selector(saveNote), for: .touchUpInside)
        btn.tintColor = .white
        btn.backgroundColor = .green
        btn.layer.cornerRadius = 6
        return btn
    }()
    private let deleteBtn : UIButton = {
        let btn = UIButton()
        btn.setTitle("", for: .normal)
        btn.addTarget(self, action: #selector(deleteNote), for: .touchUpInside)
        btn.tintColor = .white
        btn.backgroundColor = .red
        btn.layer.cornerRadius = 6
        return btn
    }()
    @objc private func saveNote()

    {
        let name = nameTxtField.text!
        let content = contantTxtView.text!
        
        let filepath = fileManagerService.getDocDir().appendingPathComponent("\(name).txt")
        do{
            try content.write(to: filepath, atomically: true, encoding: .utf8)
            
        }
        catch{
            print(error)
        }
        
    }
    @objc private func deleteNote()
        
    {
      let filepath = fileManagerService.getDocDir().appendingPathComponent("Shivaji.txt")
        do{
            try FileManager.default.removeItem(at: filepath)
        }
        catch{
            print(error)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        view.addSubview(nameTxtField)
        view.addSubview(contantTxtView)
        view.addSubview(saveBtn)
        view.addSubview(deleteBtn)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        do{
              let filepath = fileManagerService.getDocDir().appendingPathComponent("Shivaji.txt")
            let fc = try String(contentsOf: filepath)
            print(fc)
            
        }
        catch{
            print(error)
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        nameTxtField.frame = CGRect(x: 40, y: 100, width: view.width - 80, height: 40)
        contantTxtView.frame = CGRect(x: 40, y: nameTxtField.bottom + 20, width: view.width - 80, height: 300)
        saveBtn.frame = CGRect(x: 40, y: contantTxtView.bottom + 20, width: view.width - 80, height: 40)
         deleteBtn.frame = CGRect(x: 40, y: saveBtn.bottom + 20, width: view.width - 80, height: 40)    }
}
