//
//  TabelView.swift
//  Recipi
//
//  Created by DCS on 09/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class TabelView: UIViewController {

    private let myTableView = UITableView()
    private let breakfastdata = ["American Burger","MAC Aloo Tikki","French Fry"]
    private let data = ["food, substance consisting essentially of protein, carbohydrate, fat, and other nutrients used in the body of an organism to sustain growth and vital processes and to furnish energy.","food, substance consisting essentially of protein, carbohydrate, fat, and other nutrients used in the body of an organism to sustain growth and vital processes and to furnish energy.","food, substance consisting essentially of protein, carbohydrate, fat, and other nutrients used in the body of an organism to sustain growth and vital processes and to furnish energy."]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Table view"
        view.addSubview(myTableView)
        setupTable()
        myTableView.rowHeight = 200.0
        
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("hello")
        myTableView.frame=CGRect(x: 0,
                                 y : view.top,
                                 width : view.width,
                                 height:  view.height - view.safeAreaInsets.top - view.safeAreaInsets.bottom)
        
    }
    
}
extension TabelView: UITableViewDelegate,UITableViewDataSource{
    private func setupTable(){
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.register(CustomCell.self, forCellReuseIdentifier: "Cell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breakfastdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath) as! CustomCell
        cell.setupCustomCell(title: breakfastdata[indexPath.row], x:data[indexPath.row] )
        //cell.backgroundColor = .red
        //cell.frame.height = 100
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("click")
        clickdata(a:breakfastdata[indexPath.row])
    }
    func clickdata(a: String){
        UserDefaults.standard.setValue(a, forKey: "Topic")
        self.dismiss(animated: true)
        let s2 = Screen3ViewController()
        navigationController?.pushViewController(s2, animated: true)
        present(s2,animated:  true)
        
    }

}
